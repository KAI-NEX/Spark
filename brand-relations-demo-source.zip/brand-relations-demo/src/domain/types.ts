import type { CharacterRecipe } from './characterRecipe';
export interface Brand {
  id: string;
  name: string;
  category: string;
  summary: string;
  offers: string;
  needs: string;
  intent: string;
  audience: string;
  identity: string;
  constraints: string;
  characterSeed: number;
  character?: CharacterRecipe;
}

export const RELATION_TYPES = [
  'Mutual Complement', 'Capability Complement', 'Audience Bridge',
  'Creative Chemistry', 'Productive Tension', 'Production Partner',
  'Distribution Bridge', 'Cultural Exchange', 'Technology Transfer',
  'Peer / Same Tribe', 'Weak Fit',
] as const;
export type RelationType = typeof RELATION_TYPES[number];
export type Dimension = 'intentFit' | 'complementarity' | 'audienceExpansion' | 'chemistry' | 'feasibility';
export interface RelationResult extends Record<Dimension, number> {
  sourceBrandId: string;
  targetBrandId: string;
  collaborationFit: number;
  relationType: RelationType;
  reason: string;
  possibleOutcome: string;
  caveat?: string;
}
export type LOD = 'full' | 'simple' | 'marker' | 'dormant';
export interface SpatialPosition {
  brandId: string;
  x: number;
  y: number;
  radius: number;
}

export interface Viewport { x: number; y: number; zoom: number }
export interface ViewportSize { width: number; height: number; occlusions?: readonly Bounds[] }
export interface Bounds { left: number; right: number; top: number; bottom: number }
export interface SceneNode {
  brand: Brand;
  position: SpatialPosition;
  fit: number;
  isFocus: boolean;
}

/** Implement an adapter here to load snapshots / precomputed batch relations. */
export interface WorldDataSource {
  loadBrands(seed: number): readonly Brand[];
  getRelations(focus: Brand, brands: readonly Brand[]): readonly RelationResult[];
}
